package dev.tabletmods.mobrange;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class MobRangeEspClient implements ClientModInitializer {
    private static final int MAX_DISTANCE = 48;
    private static final int MAX_ROWS = 8;

    @Override
    public void onInitializeClient() {
        HudElementRegistry.addLast(
            Identifier.fromNamespaceAndPath("mob_range_esp", "mob_list"),
            MobRangeEspClient::renderHud
        );
    }

    private static void renderHud(GuiGraphics graphics, net.minecraft.client.DeltaTracker tickCounter) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.level == null || client.options.hideGui) return;

        Player player = client.player;
        List<Entity> targets = new ArrayList<>();

        for (Entity entity : client.level.entitiesForRendering()) {
            if (!(entity instanceof LivingEntity living)) continue;
            if (entity == player || !entity.isAlive() || entity instanceof Player) continue;
            if (player.distanceTo(entity) > MAX_DISTANCE) continue;
            targets.add(living);
        }

        targets.sort(Comparator.comparingDouble(player::distanceTo));
        int x = 8, y = 8, rowHeight = 12;
        int shown = Math.min(MAX_ROWS, targets.size());
        int panelWidth = 172;
        int panelHeight = 18 + shown * rowHeight;

        graphics.fill(x - 4, y - 4, x + panelWidth, y + panelHeight, 0x99081119);
        graphics.drawString(client.font, "Mob Range ESP", x, y, 0xFF66FFD8, true);
        y += 15;

        if (targets.isEmpty()) {
            graphics.drawString(client.font, "Yakinda mob yok", x, y, 0xFFCCCCCC, true);
            return;
        }

        for (int i = 0; i < shown; i++) {
            Entity entity = targets.get(i);
            int distance = (int) Math.floor(player.distanceTo(entity));
            String name = entity.getName().getString();
            if (name.length() > 15) name = name.substring(0, 15);
            String line = name + "  " + distance + " blok";
            int color = distance <= 12 ? 0xFFFF7777 : 0xFFFFD166;
            graphics.drawString(client.font, line, x, y, color, true);
            y += rowHeight;
        }
    }
}
