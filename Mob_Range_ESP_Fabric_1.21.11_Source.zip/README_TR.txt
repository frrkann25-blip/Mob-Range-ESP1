MOB RANGE ESP — Minecraft Java 1.21.11 / Fabric
================================================

Bu ZIP bir MOD KAYNAK PROJESİDİR; hazır .jar dosyası değildir.
Minecraft Java 1.21.11, Java 21, Fabric Loader ve Fabric API hedeflenir.

Özellik:
- HUD üzerinde yakındaki canlı mobları listeler.
- Her mob için yaklaşık blok mesafesini gösterir.
- 48 blok yarıçapı ve en fazla 8 satır.
- Yalnızca istemci tarafında çalışır. Ekran ortasında 3D kutu çizmez; bu ilk sürüm mesafe HUD'udur.

Android tablette bilgisayarsız:
1. Java 21 ve Gradle çalıştırabilen bir Android geliştirme ortamı veya güvenilir bir bulut IDE kullan.
2. ZIP'i açıp proje dosyalarını içe aktar.
3. Gradle ile `build` görevini çalıştır.
4. Başarılı derlemede `build/libs/` içinde `mob-range-esp-1.0.0.jar` oluşur.
5. Bu JAR'ı kullandığın Java başlatıcısının Minecraft 1.21.11 profilindeki `mods` klasörüne koy.
6. Aynı profil için Fabric Loader 1.21.11 ve uyumlu Fabric API kurulu olmalı.

ÖNEMLİ:
- Android'de Java Edition çalıştıran başlatıcıların mod desteği birbirinden farklıdır. PojavLauncher benzeri bir başlatıcı kullanıyorsan, onun Java 21 desteğini ve 1.21.11 uyumluluğunu kontrol et.
- Bazı Android başlatıcılarında Gradle ile mod derlemek zor veya mümkün olmayabilir; bu durumda bulut IDE kullanmak daha kolaydır.
- Bu proje burada gerçek Minecraft içinde derlenip test edilmedi. Derleme sırasında Loom/API sürüm hatası çıkarsa hata metniyle düzeltilebilir.
- Modu yalnızca izin verilen dünyalarda/sunucularda kullan; sunucu kuralları ESP tarzı modları yasaklayabilir.
